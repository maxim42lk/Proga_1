﻿int n1 = 5;
int n2 =5;
int[,] A;
A = new int[n1, n2];
Random rnd = new Random();

// Присвоение значений датчиком случайных чисел
for (int i = 0; i < n1; i++)
    for (int j = 0; j < n2; j++)
        A[i, j] = rnd.Next(-0, 10 + 1);

// Вывод массива
for (int i = 0; i < n1; i++, Console.WriteLine())
    for (int j = 0; j < n2; j++)
        Console.Write(A[i, j] + "\t");
int minRowSum = int.MaxValue, indexMinRow = 0;

// Сравниваем суммы всех строк между собой
for (int i = 0; i < n1; i++)
{
    int rowSum = 0;
    for (int j = 0; j < n2; j++)
        rowSum += A[i, j];

    if (rowSum < minRowSum)
    {
        minRowSum = rowSum;
        indexMinRow = i;
    }
}
// Выводим строку с наименьшей суммой элементов в строке
Console.WriteLine("Строка с минимальной суммой элементов");
for (int j = 0; j < n2; j++)
    Console.Write(A[indexMinRow, j] + "\t");